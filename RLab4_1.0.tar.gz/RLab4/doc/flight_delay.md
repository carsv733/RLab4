---
title: "Flight Delay"
author: "Caroline Svahn & Martina Sandberg"
date: "2019-02-12"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Flight Delay}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---


#Prediction of flight delay

## 1

The data sets `weather` and `flights` are loaded along with the packages `nycflights`, `dplyr`, `caret` and `RLab4` according to:












