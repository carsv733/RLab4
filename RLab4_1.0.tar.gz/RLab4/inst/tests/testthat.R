library(testthat)
library(RLab4)

test_check("RLab4")

